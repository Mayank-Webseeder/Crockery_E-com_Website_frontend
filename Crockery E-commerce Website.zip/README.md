
  # Crockery E-commerce Website

  This is a code bundle for Crockery E-commerce Website. The original project is available at https://www.figma.com/design/0t2mON7kMjLwnPiaCpkWba/Crockery-E-commerce-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  